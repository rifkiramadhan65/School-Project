-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2018 at 08:14 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_novel`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jual`
--

CREATE TABLE `tb_jual` (
  `id_pelanggan` varchar(10) NOT NULL,
  `id_novel` varchar(10) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `stok` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `uang` int(10) NOT NULL,
  `kembalian` int(10) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_jual`
--

INSERT INTO `tb_jual` (`id_pelanggan`, `id_novel`, `judul`, `stok`, `total`, `uang`, `kembalian`, `tanggal`) VALUES
('', 'C003', 'Purnama', 2, 40000, 60000, 20000, '2018-04-13'),
('001', 'C003', 'Purnama', 2, 40000, 60000, 20000, '2018-04-12'),
('10', 'C002', 'Bulan terbelah', 2, 180000, 190000, 10000, '2018-05-20'),
('5', 'C003', 'Purnama', 3, 60000, 80000, 20000, '2018-04-24'),
('rian', '10', 'Hati Biru', 2, 400000, 500000, 100000, '2018-02-20'),
('Rifki', '2', 'Dilan', 1, 3000000, 3000000, 0, '2018-02-20');

--
-- Triggers `tb_jual`
--
DELIMITER $$
CREATE TRIGGER `jual_barang` AFTER INSERT ON `tb_jual` FOR EACH ROW BEGIN
UPDATE tb_stok
SET stok = stok - NEW.stok
WHERE
id_novel = NEW.id_novel;END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_kasir`
--

CREATE TABLE `tb_kasir` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kasir`
--

INSERT INTO `tb_kasir` (`username`, `password`) VALUES
('kasir', 'kasir');

-- --------------------------------------------------------

--
-- Table structure for table `tb_stok`
--

CREATE TABLE `tb_stok` (
  `id_novel` varchar(10) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `pengarang` varchar(100) NOT NULL,
  `tahun` int(20) NOT NULL,
  `stok` int(8) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `harga` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_stok`
--

INSERT INTO `tb_stok` (`id_novel`, `judul`, `pengarang`, `tahun`, `stok`, `kategori`, `harga`) VALUES
('C001', 'Tengkuban Perahu', 'ramadhan', 2019, 10, 'Comedy', 40000),
('C002', 'Bulan terbelah', 'Andika Farman', 2018, 48, 'Romance', 90000),
('C003', 'Purnama', 'rifki', 2018, 15, 'Comedy', 20000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_jual`
--
ALTER TABLE `tb_jual`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `tb_stok`
--
ALTER TABLE `tb_stok`
  ADD PRIMARY KEY (`id_novel`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
